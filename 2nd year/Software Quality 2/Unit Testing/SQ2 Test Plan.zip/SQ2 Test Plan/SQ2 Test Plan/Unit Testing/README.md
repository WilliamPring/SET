Working with the Visual Studio Unit test Framework
Each function has 5 test only if its applicable:
- Normal Testing
- Exception Testing
- Errror Testing
- Boundary Testing

