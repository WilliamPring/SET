﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankAccountNS;

namespace AutomatedBankTest
{
    [TestClass]
    public class AutomatedBankTests
    {
        public const string DebitAmountExceedsBalanceMessage = "Debit amount exceeds balance";
        public const string DebitAmountLessThanZeroMessage = "Debit amount less than zero";

        //unit test methods
        [TestMethod]
        public void Debit_WithValidAmount_UpdatesBalance()
        {
            // setup the pre-condition - a bank account with a balance of $11.99
            double beginningBalance = 11.99;
            double debitAmount = 4.55;
            double expected = 7.44;

            // pre-condition - setup account and balnce to known state
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // test the debit() method - withdraw a "legal" amount that can be coevered by the balance
            account.Debit(debitAmount);

            // check the result
            double actual = account.Balance;
//            if(expected != actual) Assert.Fail("Sorry Buddy!");
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }

        [TestMethod]
        public void Debit_WhenBalanceIsLessThanZero_ShouldThrowArgumentOutOfRange()
        {
            // pre-condition 
            double beginningBalance = 11.99;
            double debitAmount = 20.00;

            // pre-condition - setup account and balnce to known state
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // try to debit more than what is in the account
            try
            {
                account.Debit(debitAmount);
            }
            catch (ArgumentOutOfRangeException e)
            {
                // assert
                StringAssert.Contains(e.Message, BankAccount.DebitAmountExceedsBalanceMessage);
                return;
            }
            Assert.Fail("No exception was thrown.");

        }

        [TestMethod]
        public void Debit_WhenAmountIsLessThanZero_ShouldThrowArgumentOutOfRange()
        {
            // pre-condition 
            double beginningBalance = 11.99;
            double debitAmount = -20.00;

            // pre-condition - setup account and balnce to known state
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // try to debit a negative amount -- i.e. deposit?!?!
            try
            {
                account.Debit(debitAmount);
            }
            catch (ArgumentOutOfRangeException e)
            {
                // assert
                StringAssert.Contains(e.Message, BankAccount.DebitAmountExceedsBalanceMessage);
                return;
            }
            Assert.Fail("No exception was thrown.");

        }
    }
}
