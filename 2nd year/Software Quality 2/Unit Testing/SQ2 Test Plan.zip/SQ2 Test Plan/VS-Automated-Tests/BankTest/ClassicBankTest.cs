﻿using System;
using System.Collections.Generic;
using System.Text;
using BankAccountNS;

namespace ClassicBankTest
{
    class ClassicBankTest
    {
        static int numPass = 0;
        static int numFail = 0;

        static void checkValue(double valueIs, double valueShouldBe)
        {
            double diff;
            if (valueIs > valueShouldBe)
            {
                diff = valueIs - valueShouldBe;
            }
            else
            {
                diff = valueShouldBe - valueIs;
            }

            if (diff <= 0.005)
            {
                Console.WriteLine("PASS");
                numPass++;
            }
            else
            {
                Console.WriteLine("FAIL");
                numFail++;
            }
        }
        // this is a test harness - a mainline which sets up certain condition and tests them ... 
        //   - the way that this code is written, it performs like a manual test and requires the 
        //     person running the test (ie. the developer -- that's YOU) to baby-sit it and check
        //     it's output.
        //
        static void Main(string[] args)
        {
            double  workingBalance = 11.99;

            // let's set-up a precondition !  We need to have a known commodity (in this case a bank account)
            // with known values and testable conditions ...
            BankAccount ba = new BankAccount("Mr. Bryan Walton", workingBalance);

            // now let's setup our classic test report table for output
            Console.WriteLine("Action\t\tDesired\t\tActual\t\tTest");
            Console.WriteLine("-------------\t-------------\t-------------\t-------------");

            // in our classic test harness - let's keep a running dialogue of the tests we are running and
            // also track if they pass or fail
            Console.Write("OPEN\t\t${0}\t\t${1}\t\t", workingBalance, ba.Balance);
            checkValue(ba.Balance, 11.99);

            // test the addition of funds (crediting) to the bank account ... $11.99 + $5.77 = $17.76
            ba.Credit(5.77);

            // check the current balance
            workingBalance += 5.77;
            Console.Write("CREDIT\t\t${0}\t\t${1}\t\t", workingBalance, ba.Balance);
            checkValue(ba.Balance, 17.76);


            // test the subtraction (debit) of funds from the account ... $17.76 - $11.22 = $6.54
            ba.Debit(11.22);

            // check the current balance
            workingBalance -= 11.22;
            Console.Write("DEBIT\t\t${0}\t\t${1}\t\t", workingBalance, ba.Balance);
            checkValue(ba.Balance, 6.54);
            
            // what is the final answer ??  Should be $6.54 according to my calculations ...
            Console.WriteLine("\n  >> # Tests PASSED: {0}, # Tests FAILED: {1}", numPass, numFail);
            if (numFail > 0) Console.WriteLine("     -- You've got some work to do!");
        }
    }
}
